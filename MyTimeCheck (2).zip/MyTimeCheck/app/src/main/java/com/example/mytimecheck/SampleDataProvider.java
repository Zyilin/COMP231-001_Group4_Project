package com.example.mytimecheck;

import com.example.mytimecheck.model.DataItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SampleDataProvider {

    public  static List<DataItem> dataItemList;
    public  static Map<String,DataItem> dataItemMap;

    //static initializer:It's executed when the class is loaded (or initialized,kinda like a class ctor
    static {
        //initialize as array-list and hash-map
        dataItemList = new ArrayList<>();
        dataItemMap = new HashMap<>();

        //private int Sort;
        //private String CourseId;
        //private String CourseName;
        //private String CourseProf;
        //private String CourseLocation;
        //private String CourseTime;
        //private String CourseDateDay;

        addItem(new DataItem(1,null,"Software automation","Mr.Patrick","Progress @ room A34","6pm- 9:20pm","Monday"));
        addItem(new DataItem(2,null,"Linux","Mrs.James","Progress @ room A34","6pm- 9:20pm","Tuesday"));
        addItem(new DataItem(3,null,"English","Mrs.Lola","Progress @ room A14","8am- 10:20am","Wednesday"));
        addItem(new DataItem(4,null,"Math 2","Mr.Black","Progress @ room A24","12:30pm- 2:20pm","Thursday"));
        addItem(new DataItem(5,null,"Physics","Mr.Browm","Progress @ room A35","6pm- 9:30pm","Thursday"));
        addItem(new DataItem(6,null,"French","Mr.Nano","Progress @ room A31","6pm- 9:30pm","Friday"));



    }
    //this adds the dataItem to hashmap and list
    private static void addItem(DataItem item){
        dataItemList.add(item);
        dataItemMap.put(item.getCourseName(),item);
    }

}
