package com.example.mytimecheck.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.UUID;


//for testing purpouses to get ui interation this data item class
// will represent a composite of properties located in Course,TimeTable and student Class
//The purpose of this course is to aggregate all properties needed for displaying the model for
// for use case in iteration 1 story.

public class DataItem implements Parcelable {

    private int Sort;
    private String CourseId;
    private String CourseName;
    private String CourseProf;
    private String CourseLocation;
    private String CourseTime;
    private String CourseDateDay;


    public int getSort() {
        return Sort;
    }

    public void setSort(int sort) {
        Sort = sort;
    }

    public String getCourseId() {
        return CourseId;
    }

    public void setCourseId(String courseId) {
        CourseId = courseId;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public String getCourseProf() {
        return CourseProf;
    }

    public void setCourseProf(String courseProf) {
        CourseProf = courseProf;
    }

    public String getCourseLocation() {
        return CourseLocation;
    }

    public void setCourseLocation(String courseLocation) {
        CourseLocation = courseLocation;
    }

    public String getCourseTime() {
        return CourseTime;
    }

    public void setCourseTime(String courseTime) {
        CourseTime = courseTime;
    }

    public String getCourseDateDay() {
        return CourseDateDay;
    }

    public void setCourseDateDay(String courseDateDay) {
        CourseDateDay = courseDateDay;
    }

    public DataItem(){

    }

    public DataItem(int sort, String courseId, String courseName, String courseProf,
                    String courseLocation,
                    String courseTime, String courseDateDay) {

        if (courseId == null) {
            //pass in UUID to item id
            courseId = UUID.randomUUID().toString();
        }

        Sort = sort;
        CourseId = courseId;
        CourseName = courseName;
        CourseProf = courseProf;
        CourseLocation = courseLocation;
        CourseTime = courseTime;
        CourseDateDay = courseDateDay;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(this.Sort);
        dest.writeString(this.CourseId);
        dest.writeString(this.CourseName);
        dest.writeString(this.CourseProf);
        dest.writeString(this.CourseLocation);
        dest.writeString(this.CourseTime);
        dest.writeString(this.CourseDateDay);
    }

    protected DataItem(Parcel in){
        this.Sort=in.readInt();
        this.CourseId=in.readString();
        this.CourseName=in.readString();
        this.CourseProf=in.readString();
        this.CourseLocation=in.readString();
        this.CourseTime=in.readString();
        this.CourseDateDay=in.readString();

    }


    public static final Parcelable.Creator<DataItem> CREATOR = new Parcelable.Creator<DataItem>() {
        @Override
        public DataItem createFromParcel(Parcel source) {
            return new DataItem(source);
        }

        @Override
        public DataItem[] newArray(int size) {
            return new DataItem[size];
        }
    };
}
