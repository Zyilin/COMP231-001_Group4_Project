package com.example.mytimecheck;

import android.os.Bundle;

import com.example.mytimecheck.model.DataItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetailsActivity extends AppCompatActivity {

    //---------------------------PRIVATE VARIABLES-------------------------------------//
    private TextView CourseNameText, ProfText, LocationText, TimeText, DayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final DataItem item = getIntent().getExtras().getParcelable(DataItemAdapter.ITEM_KEY);

        if (item == null) {
            throw new AssertionError("null data recived");
        }

        //text ui elements binding:
        CourseNameText= (TextView) findViewById(R.id.itemCourseNameText_details);
        ProfText= (TextView) findViewById(R.id.itemProfText_details);
        LocationText=(TextView) findViewById(R.id.itemLocationText_details);
        TimeText=(TextView) findViewById(R.id.itemTimeText_details);
        DayText=(TextView) findViewById(R.id.itemDateText_details);

        CourseNameText.setText(item.getCourseName());
        ProfText.setText(item.getCourseProf());
        LocationText.setText(item.getCourseLocation());
        TimeText.setText(item.getCourseTime());
        DayText.setText(item.getCourseDateDay());

        //===========float btn non used
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    //---------------------------------------------------//
    //-----OnStop() & OnDestroy()-----------------------//
    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    //-------------------------------------------------//

}
