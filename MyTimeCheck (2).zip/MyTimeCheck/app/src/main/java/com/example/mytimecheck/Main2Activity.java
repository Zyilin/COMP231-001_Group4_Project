package com.example.mytimecheck;

import android.os.Bundle;

import com.example.mytimecheck.model.DataItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    //main class variables
    List<DataItem> dataItemList = SampleDataProvider.dataItemList;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //sort method makes kinda random
        Collections.sort(dataItemList, new Comparator<DataItem>() {
            @Override
            public int compare(DataItem o1, DataItem o2) {
                //sorts aplhabeticly
                return o1.getCourseDateDay().compareTo(o2.getCourseDateDay());
            }
        });


        //recycler-view bind
        DataItemAdapter dataItemAdapter = new DataItemAdapter(this,dataItemList);
        RecyclerView rc = (RecyclerView) findViewById(R.id.rcView);
        layoutManager = new LinearLayoutManager(this);
        rc.setHasFixedSize(false);//only use this for fixed ammount
        rc.setLayoutManager(layoutManager);
        rc.setAdapter(dataItemAdapter);





        //===============FLOAT BTN==================
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

}
