package com.example.mytimecheck;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mytimecheck.model.DataItem;

import java.io.IOException;
import java.util.List;

public class DataItemAdapter  extends RecyclerView.Adapter<DataItemAdapter.ViewHolder>{

    //note:intent constants. make sure its static. Used as key pair on sending the intent to details
    public static final String ITEM_KEY ="item_id_key";

    //note: instance variables that make a list of Music items & context
    private List<DataItem> mItems;
    private Context mContext;

    //constructor:
    public DataItemAdapter(Context context, List<DataItem> items) {
        this.mContext = context;
        this.mItems = items;
    }

    //-----------------------------------RecyclerView adapter over-rides--------------------------------//
    //this gets my list item xml
    @Override
    public DataItemAdapter.ViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View itemView = inflater.inflate(R.layout.list_rc, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemView);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder (DataItemAdapter.ViewHolder holder,int position){
        final DataItem item = mItems.get(position);

       // try {
            holder.tvCourseName.setText("Course Name: "+item.getCourseName());
            holder.tvProf.setText("Proffessor: "+item.getCourseProf());
            holder.tvLoc.setText("Location: "+item.getCourseLocation());
            holder.tvDay.setText("Day: "+item.getCourseDateDay());
            holder.tvTime.setText("Time: "+item.getCourseTime());


            //gets images
            // String imageFile = item.getImages();
            //InputStream inputStream = mContext.getAssets().open(imageFile);
            //Drawable d = Drawable.createFromStream(inputStream, null);
            //holder.imageView.setImageDrawable(d);

       // } catch (IOException e) {
       //     e.printStackTrace();
       // }

        holder.mView.setOnClickListener(new View.OnClickListener() {//getting viewholder class and ctor
            @Override
            public void onClick(View v) {

                // 1. get item id frm dataItem class// 2. create intent
                // 3. make string constant and pass in extra

                Intent intent = new Intent(mContext,DetailsActivity.class);
                intent.putExtra(ITEM_KEY,item);//----key value pair that passes item to details
                mContext.startActivity(intent);
            }
        });
        holder.mView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(mContext, "long click: " + item.getCourseName(), Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
    //note:gets the size of the Music List
    @Override
    public int getItemCount () {
        return mItems.size();
    }
    //-----------------------------------------------------------------------------------//

    //-----------------------------------ViewHolder Class--------------------------------//
    //note: Static class that bonds the view
    //the purpose of this class is to bind the xml List_item properties
    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCourseName;
        public TextView tvProf;
        public TextView tvLoc;
        public TextView tvDay;
        public TextView tvTime;
        View mView;//---------View reference

        //constructor:
        public ViewHolder(View itemView) {
            super(itemView);

            tvCourseName= (TextView) itemView.findViewById(R.id.itemCourseNameText);
            tvProf = (TextView) itemView.findViewById(R.id.itemProfText);
            tvLoc = (TextView) itemView.findViewById(R.id.itemLocationText);
            tvDay = (TextView) itemView.findViewById(R.id.itemDateText);
            tvTime= (TextView) itemView.findViewById(R.id.itemTimeText);
            mView = itemView;//passing it view in ctor
        }
    }


}
